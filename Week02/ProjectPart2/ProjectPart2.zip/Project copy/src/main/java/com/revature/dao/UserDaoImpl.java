package com.revature.dao;

/* 
 * objects to store my records
 */
public class UserDaoImpl implements UserDao {

	@Override
	public void createNewUser() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setAccountStatus() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setAdminStatus() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void storeTransaction() {
		// TODO Auto-generated method stub
		
	}

}
