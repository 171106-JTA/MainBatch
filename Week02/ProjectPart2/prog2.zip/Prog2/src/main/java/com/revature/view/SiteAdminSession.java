package com.revature.view;

public class SiteAdminSession extends Session {

}
