// Future iteration

//package com.revature.model.interfaces.factory;
//
//import com.revature.model.interfaces.product.Product;
//
//public interface AbstractFactory<T extends Product> {
//
//	public <T extends Product> createProduct();
//}