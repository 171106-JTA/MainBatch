package com.revature.model.account;

public class DatabaseAdminAccount extends SiteAdminAccount{

}
