package com.revature.throwable;

public class QuitException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8253574473108968363L;
}
