package com.revature.model.interfaces.product;

public interface Product {

}
