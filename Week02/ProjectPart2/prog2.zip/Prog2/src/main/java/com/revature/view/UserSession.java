package com.revature.view;

public class UserSession extends Session {
	
	public static void page1() {
		
	}

}
