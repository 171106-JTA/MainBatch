// Future iteration

//package com.revature.model.interfaces.factory;
//
//import com.revature.model.interfaces.product.Pool;
//
//public class PoolFactory<T> implements AbstractFactory{
//	
//
//	@Override
//	protected void createProduct() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	
//
//}
