package com.revature.model.interfaces.dao;

public interface CredentialsDao<T> {

}
