package com.revature.view;

public class DatabaseAdminSession extends Session {

}
