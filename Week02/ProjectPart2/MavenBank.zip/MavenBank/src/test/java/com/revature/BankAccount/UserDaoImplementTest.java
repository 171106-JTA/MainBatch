package com.revature.BankAccount;

import com.revature.dao.UserDaoImplement;

public class UserDaoImplementTest {
	UserDaoImplement dao = new UserDaoImplement();
	
	@Test
	public testAlterUserStatusAndPermission() {
		
	}
}
