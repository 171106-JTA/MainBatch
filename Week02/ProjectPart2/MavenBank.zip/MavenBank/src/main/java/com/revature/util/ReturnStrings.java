package com.revature.util;

public class ReturnStrings {
	public final String USER_FOUND = "userFound";
	public final static String USER_NOT_FOUND = "userNotFound";
	public final static String WRONG_PASSWORD = "wrongPassword";
}
