package com.revature.testingOutMaven;

public class helloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World!!!!");
	}
	
	public String myHello() {
		return("Hello!!!!");
	}

}
