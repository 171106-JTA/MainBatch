package com.revature.Exceptions;

///**
// * A custom except class to handle input validation. 
// * IMPORTANT NOTE: I am using a custom exception just for the practice. 
// * In production-grade code, I would likely use an existing exception such
// * as IllegalArgumentException.
// * @author Evan
// *
// */
public class ValidationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
////	@Override
////	public String getMessage() {
////		// TODO Auto-generated method stub
////		return "Incorrect Input";
////	}
//	
//	//Taken from link below: 
//	//https://stackoverflow.com/questions/8423700/how-to-create-a-custom-exception-type-in-java
//	//Access date: 11/14/2017
//	// Parameterless Constructor
//    public validationException() {}
//
//    // Constructor that accepts a message
//    public validationException(String message)
//    {
//       super(message);
//    }
//
//
}
