package com.revature.Exceptions;

public class errorMessages {
	
//	public errorMessages() {
//		
//	}
	
	//Create a static nested class to contain all error message related to unlocking accounts
	public static  class unlockErrors {
		public static String accountAwaitingApproval(String username) {
			return ("Account \"" + username + "\"" +
					" is awaiting approval and cannot be unlocked.\n" +
					"If you are trying to approve " + username +  ", " +
					"please use option 1) Approve Client Accounts");
		}
		
		public static String alreadyUnlocked(String username) {
			return ("Account: " + username + " is already unlocked.");
		}
	}
	
}
